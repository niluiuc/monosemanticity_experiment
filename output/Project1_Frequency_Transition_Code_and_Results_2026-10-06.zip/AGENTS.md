# Research workflow

- Time is a binding constraint. Do not conduct speculative, unguided, or broad exploratory work unless it is necessary to resolve a specific blocker or test a central research claim.
- Before an experiment, state the question, its connection to the Project 1 derivations, the smallest useful test, and the criterion for stopping or extending it.
- Prefer the existing mathematical assumptions, code, and experimental infrastructure. Expand scope only when evidence from a focused test justifies it.
- Keep mathematics, controlled toy-model validation, and eventual real-model transfer as the research structure. Do not substitute benchmark construction, agent engineering, or symbolic-regression fitting for the intended contribution.
- After each experiment or analysis run, report directly in chat using bullet points what was done and what was found. Include failures, unfavorable or inconclusive results, and material limitations; distinguish proved statements from numerical observations. File updates alone do not satisfy this reporting requirement.
- Show generated scientific plots inline in chat as well as saving them, and explain their axes, main finding and evidentiary limits.
